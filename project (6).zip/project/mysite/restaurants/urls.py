from django.urls import path
from . import views
from .models import Restaurants
urlpatterns=[
path("home",views.home,name="home"),
path("<int:id>",views.detail,name="detail"),
path('<int:id>/addcomment', views.addcomment, name='addcomment'),
path('', views.restaurants_list, name='restaurants_list'),
path('contact', views.contactus, name='contactus'),
path('<int:id>/dish',views.dish,name='dish'),
]