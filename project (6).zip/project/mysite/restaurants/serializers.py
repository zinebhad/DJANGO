from rest_framework import serializers
from .models import Restaurants,ImageDetails
class ImageDetailsSerializer(serializers.ModelSerializer):
	class Meta:
		model=Restaurants
		fields='__all__'
class AjoutResSerializer(serializers.ModelSerializer):
	class Meta:
		model=ImageDetails
		fields='__all__'