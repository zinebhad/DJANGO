from django.db import models
from django import forms
from django.contrib.auth.models import User
from django.forms import ModelForm
from django.utils.safestring import mark_safe
from mptt.fields import TreeForeignKey
from django.db.models import Avg, Count
from phone_field import PhoneField
from django_countries.fields import CountryField
from django.forms import ModelForm, TextInput, Textarea


# Create your models here. 
class Restaurants(models.Model):
    Restaurant=1
    Snack=2
    Coffe=3
    TYPES = (
        (Restaurant, 'Restaurant'),
        (Snack, 'fast food'),
        (Coffe, 'Coffe'),
    )
    name = models.CharField('Restaurant Name', max_length=120)
    avatar=models.ImageField(upload_to='media',max_length=255,null=True,blank=True)
    Type=models.PositiveSmallIntegerField(choices=TYPES,null=True)
    typeCuisine=models.CharField('Type Cuisine',max_length=255,null=True,blank=True)
    Repas=models.CharField('Repas',max_length=50,null=True,blank=True)
    Telephone=PhoneField('telephone',null=True,blank=True)
    HourServices=models.TimeField(auto_now=False, auto_now_add=False,null=True)
    fonctionnalité=models.CharField('fonctionnalite',max_length=255,null=True,blank=True)
    Country=CountryField(null=True)
    City=models.CharField('city',max_length=100,null=True,blank=True)
    address=models.CharField('Restaurant Address',max_length=255,null=True,blank=True)
    latitude=models.FloatField(null=True)
    longitude=models.FloatField(null=True)

    def avaregereview(self):
        reviews = Comment.objects.filter(restaurant=self).aggregate(avarage=Avg('rate'))
        avg=0
        if reviews["avarage"] is not None:
            avg=float(reviews["avarage"])
        return avg

    def countreview(self):
        reviews = Comment.objects.filter(restaurant=self).aggregate(count=Count('id'))
        cnt=0
        if reviews["count"] is not None:
            cnt = int(reviews["count"])
        return cnt

class ImageDetails(models.Model):
	rest=models.ForeignKey('Restaurants',on_delete=models.CASCADE,related_name='image');
	pictures=models.ImageField(upload_to='media/images')

class Dishs(models.Model):
    rest=models.ForeignKey('Restaurants',on_delete=models.CASCADE,related_name='dishs');
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True, null=True)
    price = models.DecimalField('Euro amount', max_digits=8, decimal_places=2, blank=True, null=True)
    pictures=models.ImageField(upload_to='media/images')
class DishForm(ModelForm):
    name=forms.CharField()
    description=forms.CharField()
    price=forms.IntegerField()
    class Meta:
        model = Dishs
        fields = ['name', 'description', 'price']

class Comment(models.Model):
    restaurant=models.ForeignKey(Restaurants,on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.CharField(max_length=250,blank=True)
    rate = models.IntegerField(default=1)
    ip = models.CharField(max_length=20, blank=True)
    create_at=models.DateTimeField(auto_now_add=True)
    update_at=models.DateTimeField(auto_now=True)

class CommentForm(ModelForm):

    class Meta:
        model = Comment
        fields = ['comment', 'rate']
class ContactMessage(models.Model):
    name= models.CharField(blank=True,max_length=20)
    email= models.CharField(blank=True,max_length=50)
    subject= models.CharField(blank=True,max_length=50)
    message= models.TextField(blank=True,max_length=255)
    ip = models.CharField(blank=True, max_length=20)
    note = models.CharField(blank=True, max_length=100)
    create_at=models.DateTimeField(auto_now_add=True)
    update_at=models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
class ContactForm(ModelForm):
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'subject','message']
        widgets = {
            'name'   : TextInput(attrs={'class': 'input','placeholder':'Name & Surname'}),
            'subject' : TextInput(attrs={'class': 'input','placeholder':'Subject'}),
            'email'   : TextInput(attrs={'class': 'input','placeholder':'Email Address'}),
            'message' : Textarea(attrs={'class': 'input','placeholder':'Your Message','rows':'5'}),
        }