from django.contrib import admin
from .models import Restaurants,ImageDetails,Comment,ContactMessage,Dishs


# Register your models here.
admin.site.register(Restaurants)
admin.site.register(ImageDetails)
admin.site.register(Comment)
admin.site.register(ContactMessage)
admin.site.register(Dishs)
class ImageDetailInline(admin.TabularInline):
	model=ImageDetails

class Restaurant(admin.ModelAdmin):
	inlines=[ImageDetailInline]